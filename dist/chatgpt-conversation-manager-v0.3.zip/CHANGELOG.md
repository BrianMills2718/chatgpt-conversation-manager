# Changelog

## v0.3.0

### Fixed — found and fixed during live browser verification

Three real bugs surfaced only by testing against a live, authenticated chatgpt.com session (not caught by unit tests, since they're all runtime/browser-integration issues):

- **Content script never actually ran.** `manifest.json` declared `"type": "module"` on the `content_scripts` entry — but Chrome only honors `type: module` for background service workers, not content scripts. The extension loaded with no errors shown at install time, but every page load threw `Uncaught SyntaxError: Cannot use import statement outside a module` and the content script silently never executed at all (no capture, no title fix, nothing). Fixed by wrapping `content.js` in an async IIFE and switching the three `extension/lib/*.js` imports to dynamic `import(chrome.runtime.getURL(...))`, with those files declared in a new `web_accessible_resources` manifest entry.
- **Reconnect storm.** `chrome.storage.onChanged` was firing (and reconnecting the broker WebSocket) on *any* storage change — including `storage.local`, which `persistStatus()` writes after every capture. That created a feedback loop: capture → status write → reconnect → re-capture → ... Observed live: 250+ simultaneous connections to the broker, and Chrome eventually throttling new WebSocket attempts with `Insufficient resources`. Fixed by filtering the listener to `areaName === "sync"` only (settings changes from the options page), which is the only case that should trigger a reconnect. Confirmed stable at exactly 1 connection per open tab afterward, holding with no growth over time.
- **Same-origin API capture 404'd even for a valid, open, logged-in conversation.** Cookies alone turned out not to be sufficient — ChatGPT's own frontend also attaches an `Authorization: Bearer <jwt>` header, obtained from a same-origin `/api/auth/session` call. Confirmed by capturing the real outgoing request headers from a live authenticated session and diffing against what the content script was sending. Fixed by fetching that token fresh per capture (same-origin, never persisted or forwarded) and attaching it; the endpoint now returns 200 and the full conversation tree.

### Fixed

- **Title extraction ("Skip to content" bug).** Root cause: `currentConversationLink()` resolved every sidebar `<a href>` against the current page URL and matched on resolved pathname. An accessibility "Skip to content" link (`href="#main"`) resolves to the *same pathname* as the current page (only the hash differs), so it was indistinguishable from the real conversation link. Fixed by rejecting any hash-only href before path comparison, requiring the resolved path to equal `/c/<thread-id>` exactly, and preferring `aria-current="page"` when present. Title selection is now a pure, unit-tested function (`extension/lib/title.js`) with an explicit priority order and denylist, not a single hard-coded string exclusion.

### Added — reliable long-conversation capture

- **Same-origin API capture path** (`extension/lib/api-capture.js`): the content script now calls `fetch('/backend-api/conversation/<id>', { credentials: 'same-origin' })` — the same in-page request ChatGPT's own web app makes to hydrate a conversation — and linearizes the full message tree by walking the `current_node` parent chain. This is authoritative and complete: it is not affected by DOM virtualization, since it reads the conversation ChatGPT itself maintains server-side rather than whatever is currently mounted in the viewport. No cookies or credentials are exported anywhere; the request runs in-page and its response goes straight into the snapshot.
- **DOM fallback path** remains for when the API call fails (schema change, blocked, transient error). It now scrolls the conversation container to the top a few times first (best-effort mitigation for virtualization) and every DOM-sourced snapshot is tagged `capture_source: "dom"` with an explicit `completeness_warning` string, surfaced all the way to the popup. Snapshots successfully captured via the API path are tagged `capture_source: "api"` with `completeness_warning: null`.
- This directly answers the task's central open question: DOM-only capture cannot guarantee completeness of a long/virtualized conversation, but the same-origin API path can and does, and is now the default.

### Added — extension popup

- Real toolbar popup (`extension/popup.html`/`popup.js`) showing broker connection status, whether a conversation is detected, thread ID, title, last archive timestamp, last archive status/error, current project, sequence, and any completeness warning.
- Buttons: **Capture Now**, **Rename**, **Assign Project**, **Number/Sequence** — each calls the backend's REST API directly (reusing the existing broker-dispatch infrastructure) and surfaces the exact success/error text returned, never silently succeeding.

### Added — observability

- Structured status tracking in the content script (`connected`, `threadId`, `title`, `lastArchiveAt`, `lastArchiveStatus`/`lastArchiveError`, `captureSource`, `completenessWarning`), persisted to `chrome.storage.local` so it survives content-script reloads.
- Broker WS `snapshot_ack`/`snapshot_error` messages now update that status instead of being ignored.
- New optional **debug mode** (options page checkbox) gates console logging — normal users see none.
- Graceful handling of `Extension context invalidated` (the standard "unpacked extension was reloaded while an old tab is still attached" condition): detected once, timers/observer stopped, a single `console.info` explains it, and it is never surfaced to the popup as an archive failure.
- Rename automation now returns explicit, distinct errors for each UI element it fails to find (menu button, rename menu item, rename input) instead of one generic failure, and **verifies** the resulting visible title before reporting success — a rename that "ran" but didn't stick is now reported as a failure with the mismatched title shown.
- Server now logs WS connect/disconnect, rejected (bad-token) connection attempts, and snapshot errors to stdout.

### Added — lineage, status, and undo

- Thread catalog entries now carry `parent_thread_id` and `status` (`current | superseded | reference | final | abandoned`, default `current`).
- New MCP tools/REST endpoints: `set_thread_parent` / `POST /api/lineage`, `set_thread_status` / `POST /api/status`, `undo_last_organization_change` / `POST /api/undo`, `get_project_state` / (MCP only).
- `undoLastAction` reverts the most recent project assignment, sequence/series/stage change, or status change per thread, using before/after state recorded on each action (not full-object diffing, so unrelated later changes aren't clobbered).
- `numberThread` now rejects an **explicit** sequence number already used by another thread in the same project/series instead of silently overwriting it.
- Every thread's archive-side project/sequence/status change was already logged to `catalog.actions`; entries now carry enough `before` state to support the undo above.
- Visible-UI rename undo is intentionally *not* implemented as a one-click ChatGPT UI action (fragile automation on top of automation); the append-only `*.history.jsonl` already preserves every prior title for manual or future automated restoration.

### Added — search filters

- `search_archived_chats` / `GET /api/search` gained `thread_id`, `status`, `since`, `until` filters alongside the existing `project`/`limit`.

### Changed

- `server/index.js` now exports `{ app, server, archive }` and only auto-`listen()`s when run directly (`npm start`), so it can be imported for integration tests without side effects.
- `manifest.json`: content script is now loaded as an ES module (`"type": "module"`) so `content.js` can statically import the new `extension/lib/*.js` modules; added `action.default_popup`.
- Extension version and package version bumped to `0.3.0`.

### Tests

- `node --test` (Node's built-in runner, no new dependencies): 40 tests covering title selection (including the exact "Skip to content" regression), message dedup/snapshot normalization, same-origin API-tree linearization (branch selection, cycle guard, system-message filtering), archive store behavior (content-hash history dedup, sequence allocation/collision rejection, undo, lineage/status validation, search filters, checkpoint/wiki generation), and a light server integration suite (auth enforcement, 404/503 error surfacing).
- Browser/UI automation (rename, live capture against a real logged-in chatgpt.com session) is not automated — see `README.md` → Manual smoke test.

### Known limitations (see README for full detail)

- The same-origin `/backend-api/conversation/<id>` endpoint is private and undocumented; it can change without notice. The DOM fallback exists for exactly that case, but is best-effort only.
- Attachment metadata is captured when present in the API response; attachment bytes are not archived.
- Branch topology: only the currently-selected branch is captured (matches what a user viewing the conversation would see); sibling/rejected branches are not archived.
- Live-verified 2026-08-19 against a real chatgpt.com session, including a real 79-message conversation captured completely via `capture_source: "api"` — see README § "Live verification" for full results.

import crypto from "node:crypto";
import http from "node:http";
import path from "node:path";
import express from "express";
import { WebSocketServer } from "ws";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import { ArchiveStore, THREAD_STATUSES } from './archive.js';

const PORT = Number(process.env.PORT || 8787);
const AUTH_TOKEN = process.env.RENAMER_TOKEN || "change-me";
const COMMAND_TIMEOUT_MS = Number(process.env.COMMAND_TIMEOUT_MS || 15000);
const ARCHIVE_DIR = process.env.ARCHIVE_DIR || path.resolve('data');
const archive = new ArchiveStore(ARCHIVE_DIR);

const app = express();
app.use(express.json({ limit: "2mb" }));
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });
const extensionSockets = new Set();
const pending = new Map();

function authOk(req) { return (req.headers.authorization || "") === `Bearer ${AUTH_TOKEN}`; }
function cleanTitle(v) { const s = String(v || '').trim(); if (!s || s.length > 120) throw new Error('title must be 1-120 characters'); return s; }

server.on("upgrade", (req, socket, head) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname !== "/extension") return socket.destroy();
  if (url.searchParams.get("token") !== AUTH_TOKEN) {
    console.warn(`[broker] rejected extension upgrade from ${req.socket.remoteAddress}: bad or missing token`);
    return socket.destroy();
  }
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit("connection", ws, req));
});

wss.on("connection", (ws) => {
  extensionSockets.add(ws);
  console.log(`[broker] extension connected (${extensionSockets.size} total)`);
  ws.send(JSON.stringify({ type: "hello", message: "connected" }));
  ws.on("message", (buf) => {
    let msg; try { msg = JSON.parse(buf.toString()); } catch { return; }
    if (msg?.type === 'thread_snapshot') {
      try { const saved = archive.archiveSnapshot(msg.snapshot); ws.send(JSON.stringify({ type: 'snapshot_ack', thread_id: saved.thread_id, content_hash: saved.content_hash })); }
      catch (err) { console.error(`[broker] snapshot_error for ${msg.snapshot?.thread_id}: ${err.message}`); ws.send(JSON.stringify({ type: 'snapshot_error', error: err.message })); }
      return;
    }
    if (msg?.type !== "command_result" || !msg?.id) return;
    const waiter = pending.get(msg.id); if (!waiter) return;
    clearTimeout(waiter.timer); pending.delete(msg.id);
    msg.ok ? waiter.resolve(msg) : waiter.reject(new Error(msg.error || "browser action failed"));
  });
  ws.on("close", () => { extensionSockets.delete(ws); console.log(`[broker] extension disconnected (${extensionSockets.size} total)`); });
  ws.on("error", (err) => { console.error(`[broker] extension socket error: ${err.message}`); extensionSockets.delete(ws); });
});

function dispatchToExtension(command) {
  const sockets = [...extensionSockets].filter((ws) => ws.readyState === ws.OPEN);
  if (!sockets.length) throw new Error("No browser extension is connected to the broker.");
  const id = crypto.randomUUID();
  sockets.forEach((ws) => ws.send(JSON.stringify({ type: "command", id, ...command })));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pending.delete(id); reject(new Error("Timed out waiting for the browser extension.")); }, COMMAND_TIMEOUT_MS);
    pending.set(id, { resolve, reject, timer });
  });
}

async function currentThreadId() {
  const result = await dispatchToExtension({ action: 'get_current_thread_info' });
  if (!result.thread_id) throw new Error('Could not determine current ChatGPT thread ID.');
  return result.thread_id;
}

app.get("/health", (_req, res) => res.json({ ok: true, extension_connections: extensionSockets.size, archive_dir: ARCHIVE_DIR }));
app.post('/api/capture', async (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: 'unauthorized' });
  try { const result = await dispatchToExtension({ action: 'capture_current_chat' }); res.json(result); }
  catch (err) { res.status(503).json({ error: err.message }); }
});
app.post("/api/rename", async (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: "unauthorized" });
  try { const result = await dispatchToExtension({ action: "rename_current_chat", title: cleanTitle(req.body?.title) }); res.json(result); }
  catch (err) { res.status(503).json({ error: err.message }); }
});
app.get('/api/search', (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: 'unauthorized' });
  res.json({ results: archive.search(req.query.q || '', {
    project: req.query.project || null,
    limit: req.query.limit || 8,
    threadId: req.query.thread || null,
    status: req.query.status || null,
    since: req.query.since || null,
    until: req.query.until || null,
  }) });
});
app.get('/api/current', async (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: 'unauthorized' });
  try { const result = await dispatchToExtension({ action: 'get_current_thread_info' }); res.json(result); }
  catch (err) { res.status(503).json({ error: err.message }); }
});
app.get('/api/thread/:id', (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: 'unauthorized' });
  const catalog = archive.readCatalog();
  const t = catalog.threads[req.params.id];
  if (!t) return res.status(404).json({ error: `Unknown archived thread: ${req.params.id}` });
  res.json(t);
});
app.post('/api/project', async (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: 'unauthorized' });
  try {
    const project = String(req.body?.project || '').trim();
    if (!project) throw new Error('project is required');
    const id = await currentThreadId();
    const t = archive.assignProject(id, project);
    archive.writeProjectWiki(t.project_id);
    res.json(t);
  } catch (err) { res.status(err.message?.includes('No browser extension') ? 503 : 400).json({ error: err.message }); }
});
app.post('/api/number', async (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: 'unauthorized' });
  try {
    const { project, series = 'default', stage, sequence, rename_visible_chat = true } = req.body || {};
    const id = await currentThreadId();
    const t = archive.numberThread(id, { projectName: project, series, stage, sequence });
    archive.writeProjectWiki(t.project_id);
    if (rename_visible_chat) {
      const prefix = String(t.sequence).padStart(2, '0');
      const cleanBase = String(t.title || 'Untitled').replace(/^\d{1,4}\s*[—–-]\s*/, '');
      const nextTitle = `${prefix} — ${stage ? `${stage} — ` : ''}${cleanBase}`.slice(0, 120);
      await dispatchToExtension({ action: 'rename_current_chat', title: nextTitle });
    }
    res.json(t);
  } catch (err) { res.status(err.message?.includes('No browser extension') || err.message?.includes('Timed out') ? 503 : 400).json({ error: err.message }); }
});
app.post('/api/lineage', async (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: 'unauthorized' });
  try { const id = await currentThreadId(); res.json(archive.setThreadParent(id, req.body?.parent_thread_id || null)); }
  catch (err) { res.status(400).json({ error: err.message }); }
});
app.post('/api/status', async (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: 'unauthorized' });
  try { const id = await currentThreadId(); res.json(archive.setThreadStatus(id, req.body?.status)); }
  catch (err) { res.status(400).json({ error: err.message }); }
});
app.post('/api/undo', async (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: 'unauthorized' });
  try { const id = req.body?.thread_id || (await currentThreadId()); res.json(archive.undoLastAction(id)); }
  catch (err) { res.status(400).json({ error: err.message }); }
});

function createMcpServer() {
  const mcp = new McpServer({ name: "chatgpt-conversation-manager", version: "0.3.0" });

  mcp.tool('capture_current_chat', 'Capture the currently open ChatGPT conversation into the durable local archive.', {}, async () => {
    try { const r = await dispatchToExtension({ action: 'capture_current_chat' }); return { content: [{ type: 'text', text: `Captured ${r.thread_id}: ${r.title || 'Untitled'}` }] }; }
    catch (err) { return { isError: true, content: [{ type: 'text', text: `Capture failed: ${err.message}` }] }; }
  });

  mcp.tool("rename_current_chat", "Rename the currently open ChatGPT conversation. Use only when the user explicitly requests or approves the rename.", { title: z.string().min(1).max(120) }, async ({ title }) => {
    try { const r = await dispatchToExtension({ action: "rename_current_chat", title: cleanTitle(title) }); return { content: [{ type: "text", text: `Renamed the current chat to “${r.title || title}”.` }] }; }
    catch (err) { return { isError: true, content: [{ type: "text", text: `Rename failed: ${err.message}` }] }; }
  });

  mcp.tool("get_current_chat_title", "Read the title of the currently open ChatGPT conversation.", {}, async () => {
    try { const r = await dispatchToExtension({ action: "get_current_chat_title" }); return { content: [{ type: "text", text: r.title || "Current title could not be determined." }] }; }
    catch (err) { return { isError: true, content: [{ type: "text", text: `Read failed: ${err.message}` }] }; }
  });

  mcp.tool('assign_current_chat_project', 'Assign the current chat to a durable organizer project in the local archive. This does not depend on ChatGPT Projects UI.', { project: z.string().min(1).max(120) }, async ({ project }) => {
    try { const id = await currentThreadId(); const t = archive.assignProject(id, project.trim()); archive.writeProjectWiki(t.project_id); return { content: [{ type: 'text', text: `Assigned “${t.title}” to archive project “${t.project_name}”.` }] }; }
    catch (err) { return { isError: true, content: [{ type: 'text', text: `Project assignment failed: ${err.message}` }] }; }
  });

  mcp.tool('number_current_chat', 'Assign the current archived chat a sequence number within its project/series.', {
    project: z.string().min(1).max(120).optional(),
    series: z.string().min(1).max(80).default('default'),
    stage: z.string().max(80).optional(),
    sequence: z.number().int().positive().optional(),
    rename_visible_chat: z.boolean().default(true),
  }, async ({ project, series, stage, sequence, rename_visible_chat }) => {
    try {
      const id = await currentThreadId();
      const t = archive.numberThread(id, { projectName: project, series, stage, sequence });
      archive.writeProjectWiki(t.project_id);
      const prefix = String(t.sequence).padStart(2, '0');
      const cleanBase = String(t.title || 'Untitled').replace(/^\d{1,4}\s*[—–-]\s*/, '');
      const nextTitle = `${prefix} — ${stage ? `${stage} — ` : ''}${cleanBase}`.slice(0, 120);
      if (rename_visible_chat) await dispatchToExtension({ action: 'rename_current_chat', title: nextTitle });
      return { content: [{ type: 'text', text: `Numbered thread ${prefix} in “${t.project_name}”${rename_visible_chat ? ` and renamed it to “${nextTitle}”` : ''}.` }] };
    } catch (err) { return { isError: true, content: [{ type: 'text', text: `Numbering failed: ${err.message}` }] }; }
  });

  mcp.tool('search_archived_chats', 'Search the durable ChatGPT archive using lexical/project-aware retrieval. Returns source snippets for retrieval-augmented use.', {
    query: z.string().min(1), project: z.string().optional(), limit: z.number().int().min(1).max(25).default(8),
    thread_id: z.string().optional(), status: z.enum(THREAD_STATUSES).optional(), since: z.string().optional(), until: z.string().optional(),
  }, async ({ query, project, limit, thread_id, status, since, until }) => {
    const rows = archive.search(query, { project, limit, threadId: thread_id, status, since, until });
    const text = rows.length ? rows.map((r, i) => `${i + 1}. [${r.thread_id}] ${r.title}${r.project ? ` — ${r.project}` : ''}${r.status && r.status !== 'current' ? ` [${r.status}]` : ''}\n${r.snippet}`).join('\n\n') : 'No archived chats matched.';
    return { content: [{ type: 'text', text }] };
  });

  mcp.tool('set_thread_parent', 'Record a parent/lineage link for the current chat (e.g. this thread continues or revises another archived thread). Purely metadata; no automatic inference.', {
    parent_thread_id: z.string().min(1).nullable(),
  }, async ({ parent_thread_id }) => {
    try { const id = await currentThreadId(); const t = archive.setThreadParent(id, parent_thread_id); return { content: [{ type: 'text', text: parent_thread_id ? `Set parent of "${t.title}" to ${parent_thread_id}.` : `Cleared parent link for "${t.title}".` }] }; }
    catch (err) { return { isError: true, content: [{ type: 'text', text: `Set parent failed: ${err.message}` }] }; }
  });

  mcp.tool('set_thread_status', `Set the lifecycle status of the current chat. One of: ${THREAD_STATUSES.join(', ')}.`, {
    status: z.enum(THREAD_STATUSES),
  }, async ({ status }) => {
    try { const id = await currentThreadId(); const t = archive.setThreadStatus(id, status); archive.writeProjectWiki(t.project_id); return { content: [{ type: 'text', text: `Set "${t.title}" status to ${status}.` }] }; }
    catch (err) { return { isError: true, content: [{ type: 'text', text: `Set status failed: ${err.message}` }] }; }
  });

  mcp.tool('undo_last_organization_change', 'Undo the most recent archive-side organization change (project assignment, sequence/series/stage, or status) for a thread. Does not undo the visible ChatGPT UI rename or checkpoints — the append-only history preserves prior titles for manual restoration.', {
    thread_id: z.string().optional(),
  }, async ({ thread_id }) => {
    try { const id = thread_id || (await currentThreadId()); const t = archive.undoLastAction(id); if (t.project_id) archive.writeProjectWiki(t.project_id); return { content: [{ type: 'text', text: `Reverted last organization change for "${t.title}".` }] }; }
    catch (err) { return { isError: true, content: [{ type: 'text', text: `Undo failed: ${err.message}` }] }; }
  });

  mcp.tool('get_project_state', 'Get the current archive state for a project: thread index (with sequence/stage/status) and the compiled wiki page content.', {
    project: z.string().min(1),
  }, async ({ project }) => {
    const catalog = archive.readCatalog();
    const projectId = Object.values(catalog.projects).find((p) => p.name.toLowerCase() === project.toLowerCase() || p.project_id === project)?.project_id;
    if (!projectId) return { content: [{ type: 'text', text: `No archive project matches "${project}".` }] };
    const threads = Object.values(catalog.threads)
      .filter((t) => t.project_id === projectId)
      .sort((a, b) => (a.sequence || 999999) - (b.sequence || 999999));
    const summary = threads.map((t) => `${t.sequence ? String(t.sequence).padStart(2, '0') : '--'} ${t.title}${t.stage ? ` — ${t.stage}` : ''}${t.status !== 'current' ? ` [${t.status}]` : ''} (${t.thread_id})`).join('\n');
    return { content: [{ type: 'text', text: `Project "${catalog.projects[projectId].name}" — ${threads.length} thread(s):\n${summary || '(none)'}` }] };
  });

  mcp.tool('save_current_chat_checkpoint', 'Save a durable project-memory checkpoint for the current chat. The summary and decisions should reflect the conversation, not invent new facts.', {
    summary: z.string().min(1),
    status: z.enum(['proposed','accepted','rejected','superseded','unresolved','current']).default('current'),
    decisions: z.array(z.string()).default([]),
    open_questions: z.array(z.string()).default([]),
    next_steps: z.array(z.string()).default([]),
    source_message_ids: z.array(z.string()).default([]),
  }, async (cp) => {
    try { const id = await currentThreadId(); const saved = archive.saveCheckpoint(id, cp); return { content: [{ type: 'text', text: `Saved checkpoint ${saved.checkpoint_id}.` }] }; }
    catch (err) { return { isError: true, content: [{ type: 'text', text: `Checkpoint failed: ${err.message}` }] }; }
  });

  return mcp;
}

app.all("/mcp", async (req, res) => {
  if (!authOk(req)) return res.status(401).json({ error: "unauthorized" });
  const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
  const mcp = createMcpServer();
  res.on("close", () => { transport.close().catch(() => {}); mcp.close().catch(() => {}); });
  try { await mcp.connect(transport); await transport.handleRequest(req, res, req.body); }
  catch (err) { if (!res.headersSent) res.status(500).json({ error: err.message }); }
});

const isMain = import.meta.url === `file://${process.argv[1]}`;
if (isMain) {
  server.listen(PORT, () => {
    console.log(`Conversation manager listening on http://localhost:${PORT}`);
    console.log(`Archive: ${ARCHIVE_DIR}`);
    console.log(`MCP:     http://localhost:${PORT}/mcp`);
  });
}

export { app, server, archive };

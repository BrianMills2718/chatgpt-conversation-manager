// Chrome content scripts run as classic (non-module) scripts — "type": "module"
// is only valid for background service workers, not content_scripts entries, so
// static `import` here throws "Cannot use import statement outside a module".
// Dynamic import() is allowed from a classic script, so the whole file is
// wrapped in an async IIFE that awaits the imports first; everything below
// stays unchanged and closes over these bindings normally.
(async () => {
const { cleanDocumentTitle, selectTitle, isSameOriginPageAnchor } = await import(chrome.runtime.getURL("lib/title.js"));
const { buildSnapshot, snapshotFingerprint } = await import(chrome.runtime.getURL("lib/normalize.js"));
const { captureViaApi } = await import(chrome.runtime.getURL("lib/api-capture.js"));

const DEFAULTS = {
  brokerUrl: "ws://localhost:8787/extension",
  token: "change-me",
  autoArchive: true,
  autoArchiveDelayMs: 3000,
  debug: false,
};

let socket;
let reconnectTimer;
let archiveTimer;
let lastSnapshotFingerprint = null;
let isCapturing = false;
let contextInvalidated = false;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// -- status / observability --------------------------------------------------
// The popup and the broker never see raw console spam; they see this status
// object, persisted to chrome.storage.local so it survives content-script
// reloads (e.g. after `chrome://extensions` reload) even before a new capture.
const status = {
  connected: false,
  threadId: null,
  title: null,
  titleSource: null,
  url: null,
  lastArchiveAt: null,
  lastArchiveStatus: null, // 'ok' | 'error'
  lastArchiveError: null,
  captureSource: null, // 'api' | 'dom'
  completenessWarning: null,
};

async function debugEnabled() {
  try {
    const cfg = await chrome.storage.sync.get(DEFAULTS);
    return Boolean(cfg.debug);
  } catch {
    return false;
  }
}

async function log(level, message, extra) {
  if (!(await debugEnabled())) return;
  const fn = level === "error" ? console.error : level === "warn" ? console.warn : console.log;
  fn(`[conversation-manager] ${message}`, extra ?? "");
}

async function persistStatus() {
  try {
    await chrome.storage.local.set({ lastStatus: { ...status, savedAt: new Date().toISOString() } });
  } catch (err) {
    handlePossibleContextInvalidation(err);
  }
}

function setStatus(patch) {
  Object.assign(status, patch);
  persistStatus();
}

function handlePossibleContextInvalidation(err) {
  const message = String(err?.message || err || "");
  if (!message.includes("Extension context invalidated")) return false;
  if (contextInvalidated) return true;
  contextInvalidated = true;
  clearTimeout(reconnectTimer);
  clearTimeout(archiveTimer);
  try {
    observer.disconnect();
  } catch {}
  // Not an application failure: this happens whenever the unpacked extension is
  // reloaded while an old content script instance is still attached to a live
  // tab. The stale instance simply stops working until the tab is refreshed.
  console.info("[conversation-manager] Extension was reloaded; refresh this ChatGPT tab to reconnect.");
  return true;
}

// -- thread / title detection -------------------------------------------------

function currentThreadId() {
  const m = location.pathname.match(/^\/c\/([^/?#]+)/);
  return m?.[1] || null;
}

function currentConversationLink() {
  const threadId = currentThreadId();
  if (!threadId) return null;
  const anchors = [...document.querySelectorAll("nav a[href], aside a[href]")];

  const candidates = anchors.filter((a) => {
    const raw = a.getAttribute("href") || "";
    if (isSameOriginPageAnchor(raw)) return false; // reject "Skip to content"-style anchors
    let u;
    try {
      u = new URL(a.href, location.href);
    } catch {
      return false;
    }
    if (u.origin !== location.origin) return false;
    return u.pathname.replace(/\/$/, "") === `/c/${threadId}`;
  });

  if (!candidates.length) return null;
  return candidates.find((a) => a.getAttribute("aria-current") === "page") || candidates[0];
}

function visible(el) {
  if (!el) return false;
  const r = el.getBoundingClientRect();
  const s = getComputedStyle(el);
  return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
}
function normalizedText(el) {
  return (el?.innerText || el?.textContent || "").replace(/\s+/g, " ").trim();
}
async function waitFor(predicate, timeout = 5000, interval = 80) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const value = predicate();
    if (value) return value;
    await sleep(interval);
  }
  throw new Error("Timed out waiting for ChatGPT UI.");
}

// apiTitle (from the same-origin conversation-tree response, when available) is
// the most authoritative source: it is ChatGPT's own server-side title, not a
// DOM guess, so it sidesteps the whole "Skip to content" class of bug entirely.
function resolveTitle(apiTitle) {
  return selectTitle([
    { source: "api", value: apiTitle },
    { source: "sidebar-current", value: normalizedText(currentConversationLink()) },
    { source: "document-title", value: cleanDocumentTitle(document.title) },
    { source: "aria-current-nav", value: normalizedText(document.querySelector('nav a[aria-current="page"]')) },
    { source: "header-h1", value: normalizedText(document.querySelector("header h1")) },
    { source: "main-h1", value: normalizedText(document.querySelector("main h1")) },
  ]);
}

// -- DOM capture (fallback path) ----------------------------------------------

function inferRole(node) {
  const explicit = node.getAttribute?.("data-message-author-role");
  if (explicit) return explicit;
  const s = `${node.getAttribute?.("aria-label") || ""} ${node.className || ""}`.toLowerCase();
  if (/assistant/.test(s)) return "assistant";
  if (/user/.test(s)) return "user";
  return "unknown";
}

function findScrollContainer() {
  const anchor = document.querySelector('[data-message-author-role]') || document.querySelector("main");
  let node = anchor;
  for (let depth = 0; node && depth < 8; depth++, node = node.parentElement) {
    if (node.scrollHeight > node.clientHeight + 40) return node;
  }
  return null;
}

// Best-effort mitigation for virtualization when the API path is unavailable:
// scroll the conversation to the top a few times, giving lazy-mounted turns a
// chance to render, before scraping the DOM. This does not guarantee
// completeness (hence completenessWarning is still attached by the caller).
async function scrollToTopBestEffort() {
  const container = findScrollContainer();
  if (!container) return;
  let lastHeight = -1;
  for (let i = 0; i < 12; i++) {
    container.scrollTop = 0;
    await sleep(150);
    if (container.scrollHeight === lastHeight && container.scrollTop === 0) break;
    lastHeight = container.scrollHeight;
  }
}

function extractMessagesFromDom() {
  const selectors = ['[data-message-author-role]', "main article", 'main [data-testid^="conversation-turn"]'];
  let nodes = [];
  for (const sel of selectors) {
    nodes = [...document.querySelectorAll(sel)].filter(visible);
    if (nodes.length >= 2) break;
  }
  const seen = new Set();
  const messages = [];
  for (const node of nodes) {
    const container = node.closest("[data-message-author-role]") || node;
    const role = inferRole(container);
    const messageId = container.getAttribute?.("data-message-id") || container.id || null;
    const text = normalizedText(container);
    if (!text) continue;
    const key = `${role}:${messageId || text.slice(0, 160)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    messages.push({ message_id: messageId, role, text });
  }
  return messages;
}

// -- snapshot capture ----------------------------------------------------------

async function captureSnapshot() {
  const threadId = currentThreadId();
  if (!threadId) throw new Error("Open a normal ChatGPT conversation (/c/…) before capturing.");

  let apiResult = null;
  let apiError = null;
  try {
    apiResult = await captureViaApi(threadId);
  } catch (err) {
    apiError = err;
    await log("warn", `same-origin API capture failed, falling back to DOM: ${err.message}`);
  }

  if (apiResult && apiResult.messages.length) {
    const { title, source } = resolveTitle(apiResult.title);
    return buildSnapshot({
      threadId,
      title,
      titleSource: source,
      url: location.href,
      messages: apiResult.messages,
      captureSource: "api",
      completenessWarning: null,
    });
  }

  await scrollToTopBestEffort();
  const domMessages = extractMessagesFromDom();
  const { title, source } = resolveTitle(null);
  return buildSnapshot({
    threadId,
    title,
    titleSource: source,
    url: location.href,
    messages: domMessages,
    captureSource: "dom",
    completenessWarning: apiError
      ? `Same-origin API capture unavailable (${apiError.message}); used DOM scraping, which cannot guarantee complete history on long/virtualized conversations.`
      : null,
  });
}

async function sendSnapshot(force = false) {
  if (contextInvalidated) {
    if (force) throw new Error("Extension was reloaded; refresh this ChatGPT tab to reconnect before capturing.");
    return null;
  }
  if (!currentThreadId()) {
    if (force) throw new Error("Open a normal ChatGPT conversation (/c/…) before capturing.");
    return null;
  }
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    if (force) throw new Error("Not connected to the broker (is the backend running and is the token correct?).");
    return null;
  }
  if (isCapturing) {
    if (force) throw new Error("A capture is already in progress; try again in a moment.");
    return null;
  }
  isCapturing = true;
  try {
    const snapshot = await captureSnapshot();
    const fp = snapshotFingerprint(snapshot);
    if (!force && fp === lastSnapshotFingerprint) return snapshot;
    lastSnapshotFingerprint = fp;
    socket.send(JSON.stringify({ type: "thread_snapshot", snapshot }));
    setStatus({
      threadId: snapshot.thread_id,
      title: snapshot.title,
      titleSource: snapshot.title_source,
      url: snapshot.url,
      captureSource: snapshot.capture_source,
      completenessWarning: snapshot.completeness_warning,
    });
    return snapshot;
  } catch (err) {
    setStatus({ lastArchiveStatus: "error", lastArchiveError: err.message });
    await log("error", "capture failed", err);
    throw err;
  } finally {
    isCapturing = false;
  }
}

function scheduleArchive() {
  if (contextInvalidated) return;
  clearTimeout(archiveTimer);
  chrome.storage.sync
    .get(DEFAULTS)
    .then((cfg) => {
      if (!cfg.autoArchive || !currentThreadId()) return;
      archiveTimer = setTimeout(() => {
        sendSnapshot(false).catch(() => {});
      }, Number(cfg.autoArchiveDelayMs) || 3000);
    })
    .catch((err) => handlePossibleContextInvalidation(err));
}

// -- visible-UI rename ---------------------------------------------------------

function findMenuButtonNear(link) {
  let node = link;
  for (let depth = 0; node && depth < 5; depth++, node = node.parentElement) {
    const buttons = [...node.querySelectorAll("button")].filter(visible);
    const labeled = buttons.find((b) => /menu|more|options/i.test(`${b.getAttribute("aria-label") || ""} ${b.getAttribute("title") || ""}`));
    if (labeled) return labeled;
    if (buttons.length === 1) return buttons[0];
  }
  return null;
}
function findRenameMenuItem() {
  return [...document.querySelectorAll('[role="menuitem"], button, [role="button"]')]
    .filter(visible)
    .find((el) => /^rename$/i.test(normalizedText(el)) || /rename/i.test(`${el.getAttribute("aria-label") || ""} ${normalizedText(el)}`));
}
function findRenameInput() {
  const inputs = [...document.querySelectorAll('input[type="text"], input:not([type]), textarea')].filter(visible);
  return inputs.find((i) => /rename|title|conversation/i.test(`${i.getAttribute("aria-label") || ""} ${i.getAttribute("placeholder") || ""}`)) || inputs.at(-1);
}
function setNativeValue(input, value) {
  const proto = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  setter ? setter.call(input, value) : (input.value = value);
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
}

async function renameViaVisibleUi(title) {
  if (!currentThreadId()) throw new Error("Open a normal ChatGPT conversation (/c/…) before renaming.");
  let link, menuButton, menuItem, input;
  try {
    link = await waitFor(currentConversationLink, 4000);
  } catch {
    throw new Error("Could not find the current conversation's sidebar entry to rename.");
  }
  link.scrollIntoView({ block: "nearest" });
  link.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
  await sleep(150);
  try {
    menuButton = await waitFor(() => findMenuButtonNear(link), 2500);
  } catch {
    throw new Error("Could not find the conversation's menu button (ChatGPT UI may have changed).");
  }
  menuButton.click();
  try {
    menuItem = await waitFor(findRenameMenuItem, 3000);
  } catch {
    throw new Error("Could not find a 'Rename' menu item (ChatGPT UI may have changed).");
  }
  menuItem.click();
  try {
    input = await waitFor(findRenameInput, 3000);
  } catch {
    throw new Error("Could not find the rename text input (ChatGPT UI may have changed).");
  }
  input.focus();
  setNativeValue(input, title);
  const dialog = input.closest('[role="dialog"]') || input.parentElement?.parentElement;
  const buttons = [...(dialog || document).querySelectorAll("button")].filter(visible);
  const save = buttons.find((b) => /^(save|rename|confirm)$/i.test(normalizedText(b))) || buttons.find((b) => /save|rename/i.test(normalizedText(b)));
  if (save) save.click();
  else input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true }));
  await sleep(500);
  scheduleArchive();

  const resolved = resolveTitle(null).title;
  if (!resolved || resolved.toLowerCase() !== title.toLowerCase()) {
    throw new Error(`Rename was submitted but the visible title now reads "${resolved || "(undetected)"}" instead of "${title}". Verify manually — automation ran but success is not confirmed.`);
  }
  return resolved;
}

// -- broker command handling ----------------------------------------------------

async function handleCommand(msg) {
  if (msg.action === "get_current_chat_title") return { title: resolveTitle(null).title };
  if (msg.action === "get_current_thread_info") {
    const threadId = currentThreadId();
    return {
      thread_id: threadId,
      title: resolveTitle(null).title,
      url: location.href,
      capture_source: threadId === status.threadId ? status.captureSource : null,
      completeness_warning: threadId === status.threadId ? status.completenessWarning : null,
    };
  }
  if (msg.action === "capture_current_chat") {
    const s = await sendSnapshot(true);
    return { thread_id: s.thread_id, title: s.title, message_count: s.messages.length, capture_source: s.capture_source, completeness_warning: s.completeness_warning };
  }
  if (msg.action === "rename_current_chat") {
    const title = String(msg.title || "").trim();
    if (!title || title.length > 120) throw new Error("Title must be 1-120 characters.");
    return { title: await renameViaVisibleUi(title), thread_id: currentThreadId() };
  }
  throw new Error(`Unknown action: ${msg.action}`);
}

// -- broker connection ------------------------------------------------------------

async function connect() {
  if (contextInvalidated) return;
  clearTimeout(reconnectTimer);
  let cfg;
  try {
    cfg = await chrome.storage.sync.get(DEFAULTS);
  } catch (err) {
    if (handlePossibleContextInvalidation(err)) return;
    throw err;
  }
  let url;
  try {
    url = new URL(cfg.brokerUrl || DEFAULTS.brokerUrl);
  } catch {
    setStatus({ connected: false, lastArchiveError: "Invalid broker URL in extension options." });
    return;
  }
  url.searchParams.set("token", cfg.token || DEFAULTS.token);
  socket = new WebSocket(url.toString());
  socket.onopen = () => {
    setStatus({ connected: true });
    log("info", "broker connected");
    scheduleArchive();
  };
  socket.onmessage = async (event) => {
    let msg;
    try {
      msg = JSON.parse(event.data);
    } catch {
      return;
    }
    if (msg.type === "hello") return;
    if (msg.type === "snapshot_ack") {
      setStatus({ lastArchiveAt: new Date().toISOString(), lastArchiveStatus: "ok", lastArchiveError: null });
      return;
    }
    if (msg.type === "snapshot_error") {
      setStatus({ lastArchiveStatus: "error", lastArchiveError: msg.error || "Archive rejected by broker." });
      await log("error", "broker rejected snapshot", msg.error);
      return;
    }
    if (msg.type !== "command") return;
    try {
      const result = await handleCommand(msg);
      socket.send(JSON.stringify({ type: "command_result", id: msg.id, ok: true, ...result }));
    } catch (err) {
      socket.send(JSON.stringify({ type: "command_result", id: msg.id, ok: false, error: err.message }));
      await log("error", `command ${msg.action} failed`, err);
    }
  };
  socket.onclose = () => {
    setStatus({ connected: false });
    if (!contextInvalidated) reconnectTimer = setTimeout(connect, 2000);
  };
  socket.onerror = () => {
    setStatus({ connected: false, lastArchiveError: "Broker connection error (is the backend running and is the token correct?)." });
    socket.close();
  };
}

const observer = new MutationObserver(() => scheduleArchive());
observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
window.addEventListener("popstate", scheduleArchive);
window.addEventListener("focus", scheduleArchive);
setInterval(() => {
  if (!contextInvalidated) scheduleArchive();
}, 15000);

// Only reconnect when broker settings actually change (storage.sync, written
// by the options page). storage.local is written on every status update
// (persistStatus()) — reacting to that too created a feedback loop: capture
// -> status write -> reconnect -> re-capture -> ... which flooded the broker
// with connections (observed: 250+ simultaneous sockets, Chrome eventually
// throttling new WebSocket attempts with "Insufficient resources").
chrome.storage.onChanged.addListener((_changes, areaName) => {
  if (areaName !== "sync") return;
  try {
    socket?.close();
  } catch {}
  connect();
});
connect();
})();
